package com.exception.customer;

public class CMSException extends Exception {
	public CMSException(String errMesg) {
		super(errMesg);
	}
}
